// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

var VesselSDK = require('io.vessel');
VesselSDK.setCustomFilterProperties({'paid_user': 'no'});
VesselSDK.initialize('eWlIRzc2aHU5T2diV2xOUm5kc3I1cTJE');

Ti.API.info("module is => " + VesselSDK);
VesselSDK.initializeVesselPush("442246671759");
var op = VesselSDK.isTestActive("testName");
Ti.API.info("vessel Is Test Active? " + op);
VesselSDK.setUserAttributes({'name': 'TestName',
'gender': 'male',
'address': '50E 3rd St',
'country': 'USA',
'state': 'CA',
'zipcode': '411000',
'twitter_id': '123',
'facebook_id': '222',
'linkedin_id': '444',
'paid_user': 'true',
'install_source': 'facebook_ad',
'city': 'Mountain View',
'email': 'dev@vessel.io',
});



VesselSDK.getVariationForTest("testName", function(e) {

	Ti.API.info("Vessel - testName is available, op: " + e.variation);
	// Test Available	
},
 function(e) {
 	// Test Not available
 	Ti.API.info("Vessel - testName is not available, op: " + e.variation);
 });

/*
label.text = vesselsdk.example();

Ti.API.info("module exampleProp is => " + vesselsdk.exampleProp);
vesselsdk.exampleProp = "This is a test value";

if (Ti.Platform.name == "android") {
	var proxy = vesselsdk.createExample({
		message: "Creating an example Proxy",
		backgroundColor: "red",
		width: 100,
		height: 100,
		top: 100,
		left: 150
	});

	proxy.printMessage("Hello world!");
	proxy.message = "Hi world!.  It's me again.";
	proxy.printMessage("Hello world!");
	win.add(proxy);
}

*/